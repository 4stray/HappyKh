<template>
 <div class="home">
   <img alt="Vue logo" src="../assets/logo.png">
   <HomeComponent msg="Welcome to HappyKh"/>
 </div>
</template>

<script>
   // @ is an alias to /src
   import HomeComponent from '@/components/HomeComponent.vue';

   export default {
       name: 'home',
       components: {
           HomeComponent,
       },
   };
</script>
